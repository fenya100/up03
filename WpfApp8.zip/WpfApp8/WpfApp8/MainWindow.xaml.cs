﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Windows.Media.Animation;

namespace WpfApp8
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private Storyboard myStoryboard;
        public MainWindow()
        {
            InitializeComponent();
            StackPanel myPanel = new StackPanel();
            myPanel.Margin = new Thickness(10);
            Rectangle myRectangle = new Rectangle();
            myRectangle.Name = "myRectangle";
            this.RegisterName(myRectangle.Name,
             myRectangle);
            myRectangle.Width = 100;
            myRectangle.Height = 100;
            myRectangle.Fill = Brushes.Blue;
            DoubleAnimation myDoubleAnimation =
            new DoubleAnimation();
            myDoubleAnimation.From = 1.0;
            myDoubleAnimation.To = 0.0;
            myDoubleAnimation.Duration =
           new Duration(TimeSpan.FromSeconds(5));
            myDoubleAnimation.AutoReverse = true;
            myDoubleAnimation.RepeatBehavior =
            RepeatBehavior.Forever;
            myStoryboard = new Storyboard();
            myStoryboard.Children.Add(myDoubleAnimation);
            Storyboard.SetTargetName(myDoubleAnimation,
            myRectangle.Name);
            Storyboard.SetTargetProperty(myDoubleAnimation,
            new PropertyPath(Rectangle.OpacityProperty));
            myRectangle.Loaded += new
            RoutedEventHandler(myRectangleLoaded);
            myPanel.Children.Add(myRectangle);
            this.Content = myPanel;
        }
        private void myRectangleLoaded(object sender,
RoutedEventArgs e)
        {
            myStoryboard.Begin(this);
        }
    }
}
