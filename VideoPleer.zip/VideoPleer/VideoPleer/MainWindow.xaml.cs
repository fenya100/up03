﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace VideoPleer
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        bool flag = true; 
        DispatcherTimer MyTimer = new DispatcherTimer();

        public MainWindow()
        {
            InitializeComponent();  
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            media.Source = new Uri(@"D:\Fenix\VideoPleer\VideoPleer\Video\Video1.avi");
            media.Play();
            InitializePropertyValues();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            media.Stop();
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            media.Pause();
        }

        void InitializePropertyValues()
        {
            media.Volume = (double)volumeSlider.Value;
            media.SpeedRatio = (double)speedSlider.Value;
        }

        private void ChangeMediaVolume(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            media.Volume = (double)volumeSlider.Value;
        }

        private void ChangeSpeedRatio(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            media.SpeedRatio = (double)speedSlider.Value;
        }

        private void MediaOpened(object sender, RoutedEventArgs e)
        {
            timelineSlider.Maximum = media.NaturalDuration.TimeSpan.TotalSeconds;
        }

        private void MediaEnded(object sender, RoutedEventArgs e)
        {
            media.Stop();
            flag = false;
            timelineSlider.Value = 0;
        }
        private void MyTimer_Tick(object sender, EventArgs e)
        {
            flag = true;
            timelineSlider.Value = media.Position.TotalSeconds;
            Label1.Content = media.Position.TotalSeconds.ToString();
            flag = false;
        }

        private void ChangeMediaPosition(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            flag = false;
            if (!flag) 
                media.Position = TimeSpan.FromSeconds(timelineSlider.Value);           
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            MyTimer = new DispatcherTimer();
            MyTimer.Tick += new EventHandler(MyTimer_Tick);
            MyTimer.Interval = new TimeSpan(100000);
            MyTimer.Start();
            timelineSlider.AddHandler(MouseLeftButtonUpEvent, new MouseButtonEventHandler(timelineSlider_MouseLeftButtonUp), true);
        }

        private void timeSlider_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
              
        }

        private void timelineSlider_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            media.Play(); 
        }
    }
}
